from django.shortcuts import render
from .models import *

def home(request):
    c = Course.objects.all()
    return render(request,'index.html',{'c':c})


def s(request):
    if request.method == 'POST':
        s = request.POST.get('search')
        obj = Course.objects.filter(id__icontains=s)

    return render(request,'result.html',{'obj':obj})
    
